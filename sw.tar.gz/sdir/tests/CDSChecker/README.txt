These tests require CDSChecker to be checked out into a subdirectory
named 'model-checker'.

CDSChecker can be obtained from: git://demsky.eecs.uci.edu/model-checker.git
The version last used for testing was: 5c4efe5cd8bdfe1e85138396109876a121ca61d1
