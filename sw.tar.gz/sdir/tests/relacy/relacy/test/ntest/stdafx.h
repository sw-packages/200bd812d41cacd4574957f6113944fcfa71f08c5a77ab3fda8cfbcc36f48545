#ifndef STDAFX_H
#define STDAFX_H
#ifdef _MSC_VER
#   pragma once
#endif


#include "../relacy/pch.hpp"


#endif

