#define malloc(x) malloc(x)
#define free(x) free(x)

#include "../../blockingconcurrentqueue.h"
